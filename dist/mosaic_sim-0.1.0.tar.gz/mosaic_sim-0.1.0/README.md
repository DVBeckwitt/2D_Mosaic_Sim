# 2D Mosaic Simulation

Interactive tools for visualizing how reciprocal-space features intersect the Ewald sphere and map onto detector-space observables for layered or mosaic materials.

## Current PNG Gallery (`docs/images`)

All current PNG assets in `docs/images` are shown below so the README top matches what is in the repo right now.

### `docs/images/mono_cylinder` (captured from `single_crystal_powder_cylinder_viewer.py`)

| Single Crystal | 3D Powder |
| --- | --- |
| ![Single crystal reciprocal-space view](docs/images/mono_cylinder/mono_single_crystal.png) | ![3D powder reciprocal-space view](docs/images/mono_cylinder/mono_3d_powder.png) |
| 2D Powder | Cylinder |
| ![2D powder reciprocal-space view](docs/images/mono_cylinder/mono_2d_powder.png) | ![Cylinder reciprocal-space view](docs/images/mono_cylinder/mono_cylinder.png) |

### Reciprocal-space mode explanations

1. `Single Crystal`: Discrete reciprocal-lattice points. You only get scattering when a point lies on the Ewald sphere.
2. `3D Powder`: Lattice points are azimuthally averaged into full spherical shells (`|G|` constant), producing full rings when intersected.
3. `2D Powder`: In-plane averaging with out-of-plane order gives reciprocal rings (`|G_r|` at fixed `G_z`), producing ring-arc behavior.
4. `Cylinder`: Reciprocal features extend continuously along `qz`, modeling rod-like scattering from layered/fibrous order.

### `docs/images/placeholders` (PNG placeholders to replace with real screenshots)

These are intentionally temporary images. Keep the same filenames when you replace them with real captures.

### Detector Mosaic/Ewald View (`detector_mosaic_ewald_view.py`)

![Detector feature placeholder](docs/images/placeholders/detector_placeholder.png)

- File: `docs/images/placeholders/detector_placeholder.png`
- Purpose: 3-panel browser UI linking reciprocal-space geometry to detector intensity and centered integration, with live `theta_i`, HKL, `σ`, `Γ`, and `η` controls in the GUI.
- What to capture: Full figure with all three panels visible, including colorbar, integration subplot, and the `theta_i` control.
- Run: `python detector_mosaic_ewald_view.py 0 0 12 --sigma 0.8 --gamma 5 --eta 0.5 --wavelength-bandwidth-pct 0.5`
  The CLI values seed the initial browser state; you can then change HKL and the mosaic parameters directly in the GUI.

### Fibrous Bragg/Ewald Intersections (`fibrous_bragg_ewald_intersections.py`)

![Fibrous feature placeholder](docs/images/placeholders/fibrous_placeholder.png)

- File: `docs/images/placeholders/fibrous_placeholder.png`
- Purpose: Browser-based Bragg/Ewald/cylinder intersection view with live HKL / `σ` / `Γ` / `η` controls below the plot.
- What to capture: A frame showing all three overlap curves clearly (`Ewald/Bragg`, `Cylinder/Ewald`, `Cylinder/Bragg`).
- Run: `python fibrous_bragg_ewald_intersections.py 0 0 12 --sigma 0.8 --gamma 5 --eta 0.5 --wavelength-bandwidth-pct 0.5`
  The CLI values seed the initial browser state; you can then change HKL and the mosaic parameters directly in the GUI.

## Installation

The project targets Python `3.11+`.

```bash
pip install -e .
```

## Project Status

Status date: 2026-05-12

- Feature: `Special Cause Reciprocal` is implemented in the unified GUI. It renders the Cu-K alpha Ewald shell, Bi2Se3 Bragg sphere, continuous Bragg/Ewald overlap band, and sampled green Bragg/Ewald overlap lines as a one-panel reciprocal-space view using the same HKL, `theta_i`, `σ`, `Γ`, and `η` controls as `Mosaic View`. Its defaults are `theta_i = 5°`, `(H,K,L) = (0,0,3)`, and `λ bandwidth (%) = 5.0`.
- Feature: finite Ewald wavelength spread is available through `λ bandwidth (%)` for mosaic detector, special-cause reciprocal, and fibrous views. Special-cause reciprocal uses the bandwidth as a hollow Ewald shell plus one green Bragg/Ewald overlap line per sampled bandwidth layer; mosaic detector and fibrous views keep the sampled layer-stack rendering. The default `0.0` keeps the previous monochromatic behavior in mosaic detector and fibrous views.
- Feature: unified GUI navigation has been refreshed. The mode picker now uses styled full-width choices on small screens, the powder peak filters use shared CSS classes instead of inline style dictionaries, and inactive powder peak selector cards are no longer constructed.
- Feature: special-cause reciprocal rendering now uses uniform opaque geometry traces and an RGB Bragg colorscale so the shell/band surfaces render consistently in Plotly.
- Browser runtime status: local Dash/Chromium verification confirms `Special Cause Reciprocal` at `λ bandwidth = 5.00%` now renders seven live green `Bragg/Ewald overlap` line traces, one overlap band, and the inner/outer shell traces with no failed requests and no HTTP `>=400` responses. Console output only showed expected Plotly/Chromium Canvas2D/WebGL performance warnings.
- Bug/error status: fixed the non-zero special-cause bandwidth bug where the green Bragg/Ewald intersection did not widen into sampled overlap lines for each Ewald bandwidth layer. No current application runtime error is known for this change.
- Migration status: no existing mode, CLI argument, console entry point, public Python function signature, or public Dash component ID was removed. Existing detector/fibrous scripts keep their previous behavior unless `--wavelength-bandwidth-pct` is supplied. Direct callers of `build_special_cause_reciprocal_figure()` still use the special-case `(0,0,3)` / `5%` default; pass `L=12, wavelength_bandwidth_pct=0.0` for the old direct-call default view.
- CI status: GitHub Actions runs install, `pip check`, compile, tests, and package build on pull requests and pushes to `main` across Python 3.11 and 3.13.
- Shipping status: local `pip check`, detector tests, full test suite, compile, package build, browser runtime verification, and diff whitespace checks pass for this update; rollback is a normal git revert of this bug-fix commit.

## Usage

Run scripts from the project root:

```bash
python mosaic_simulator.py                                          # unified GUI for the supported simulations
python mosaic_simulator.py --mode specular-view                     # open the unified GUI directly in Specular Diffraction mode
python mosaic_simulator.py --mode special-cause-reciprocal          # one-panel Cu-Kα/Bi2Se3 reciprocal-space overlap view, defaulting to theta_i=5°, (0,0,3), and 5% bandwidth
python single_crystal_powder_cylinder_viewer.py                # single-crystal / 3D powder / 2D powder / cylinder views
python single_crystal_powder_cylinder_viewer.py --full-quality # higher quality render profile
python detector_mosaic_ewald_view.py 0 0 12 --sigma 0.8 --gamma 5 --eta 0.5  # launches the detector Dash UI with live HKL/mosaic controls
python detector_mosaic_ewald_view.py 0 0 12 --sigma 0.8 --gamma 5 --eta 0.5 --wavelength-bandwidth-pct 0.5  # adds a finite Ewald wavelength layer stack
python fibrous_bragg_ewald_intersections.py 0 0 12 --sigma 0.8 --gamma 5 --eta 0.5  # fibrous Bragg/Ewald/cylinder GUI with live HKL/mosaic controls
python fibrous_bragg_ewald_intersections.py 0 0 12 --sigma 0.8 --gamma 5 --eta 0.5 --wavelength-bandwidth-pct 0.5  # adds a finite Ewald wavelength layer stack
python specular_reflection_sim.py                                  # standalone specular diffraction GUI with lab geometry plus reciprocal-space / integrated-response companion panels
```

`λ bandwidth (%)` is the full `Δλ / λ` percentage, not FWHM. The default `0.0` keeps the monochromatic Ewald sphere behavior.

The unified GUI includes these switchable modes in one Dash app:

- `Powder Views`
- `Mosaic View`
- `Special Cause Reciprocal`
- `Ewald Cylinder`
- `Specular Diffraction`

`Special Cause Reciprocal` is the reciprocal-space panel of the mosaic detector geometry by itself. It uses the Cu-Kα Ewald sphere size, the Bi2Se3 `d_hex(H,K,L)` Bragg-sphere size, and the Bragg/Ewald intersection with the same HKL, `theta_i`, `σ`, `Γ`, `η`, and `λ bandwidth (%)` controls as `Mosaic View`. With non-zero bandwidth, it shows the hollow Ewald shell, the continuous overlap band, and one green overlap line for each sampled Ewald layer. This mode opens at `theta_i = 5°` on the `(0,0,3)` peak with `5%` bandwidth by default.

### Specular Diffraction notes

- Default specular HKL is `(1, 1, 1)`.
- Default specular detector size is `1000 x 1000`.
- The specular UI shows a lab-geometry figure together with a companion reciprocal-space and centered-integration figure.
- In the lab geometry, outgoing diffraction rays are rendered with transparent red traces and outward arrowheads.

Installed console entry points:

- `mosaic-simulator`
- `mosaic-single-crystal-powder-cylinder-viewer`
- `mosaic-detector-mosaic-ewald-view`
- `mosaic-fibrous-bragg-ewald-intersections`
