"""Unified Dash application for the supported simulation views."""

from __future__ import annotations

import argparse
import copy
from functools import lru_cache
import json
import math
from pathlib import Path
import threading
import webbrowser
from dataclasses import dataclass, replace
from typing import Any, Callable

import plotly.graph_objects as go
from dash import ALL, MATCH, Dash, Input, Output, State, ctx, dcc, html
from dash.exceptions import PreventUpdate
from plotly.subplots import make_subplots

from specular_reflection_sim import (
    BeamConfig as SpecularBeamConfig,
    CONTROL_SECTIONS as SPECULAR_CONTROL_SECTIONS,
    DiffractionConfig as SpecularDiffractionConfig,
    DetectorConfig as SpecularDetectorConfig,
    MathLabel as SpecularMathLabel,
    SampleConfig as SpecularSampleConfig,
    SPECULAR_ADVANCED_CONTROL_SECTIONS,
    SPECULAR_BASIC_CONTROL_NAMES,
    SPECULAR_COMPANION_CONTROL_NAMES,
    SPECULAR_COMPANION_SIGNATURE_META,
    SPECULAR_CONTROL_NAMES,
    SPECULAR_MAIN_SIGNATURE_META,
    build_specular_companion_error_figure,
    build_specular_companion_figure,
    build_specular_dashboard_outputs as build_specular_dashboard_views,
    build_specular_error_figure,
    build_specular_outputs,
    build_specular_summary_card,
    build_specular_summary_output,
    configs_from_values as specular_configs_from_values,
    extract_figure_meta_value,
    extract_scene_camera_from_figure_value,
    set_figure_meta_value,
    specular_signature_from_values,
)

from .cylinder import build_cylinder_figure, normalize_cylinder_params
from .detector import (
    DEFAULT_THETA_DEG,
    SPECIAL_CAUSE_DEFAULT_EWALD_SHELL_SAMPLE_COUNT,
    SPECIAL_CAUSE_DEFAULT_L,
    SPECIAL_CAUSE_MAX_EWALD_SHELL_SAMPLE_COUNT,
    SPECIAL_CAUSE_MIN_EWALD_SHELL_SAMPLE_COUNT,
    SPECIAL_CAUSE_DEFAULT_WAVELENGTH_BANDWIDTH_PCT,
    THETA_MAX_DEG,
    THETA_MIN_DEG,
    build_detector_figure,
    build_special_cause_reciprocal_figure,
    extract_scene_camera,
    normalize_detector_params,
)
from .geometry import WAVELENGTH_BANDWIDTH_CONTROL_MAX_PCT
from .mono import N_FRAMES_DEFAULT, build_mono_figure

__all__ = [
    "DEFAULT_HOST",
    "DEFAULT_PORT",
    "DEFAULT_MODE",
    "SIMULATION_SPECS",
    "build_unified_figure",
    "build_unified_app",
    "main",
]

DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8052
DEFAULT_MODE = "reciprocal-space"
DEFAULT_POWDER_VIEW = "single-crystal"
SPECULAR_MODE = "specular-view"
SPECIAL_CAUSE_RECIPROCAL_MODE = "special-cause-reciprocal"
SPECIAL_CAUSE_DEFAULT_THETA_I_DEG = 5.0
SPECIAL_CAUSE_MATRIX_THETA_DEG = (5.0, 10.0, 15.0)
SPECIAL_CAUSE_MATRIX_L_VALUES = (3, 6, 9)
SPECIAL_CAUSE_MATRIX_EXPORT_SIZE_PX = 1800
POWDER_SPHERE_SELECTION_KEY = "sphere_selection"
POWDER_RING_SELECTION_KEY = "ring_selection"
POWDER_CYLINDER_SELECTION_KEY = "cylinder_selection"
SCENE_CAMERA_MODES = frozenset(
    {
        DEFAULT_MODE,
        "detector-view",
        SPECIAL_CAUSE_RECIPROCAL_MODE,
        "fibrous-view",
        SPECULAR_MODE,
    }
)
PNG_EXPORT_CLIENTSIDE_CALLBACK = """
        function(nClicks, modeValue) {
            if (!nClicks) {
                return "";
            }

            const graphContainer = document.getElementById("simulation-figure");
            const graph = graphContainer?.querySelector?.(".js-plotly-plot") || graphContainer;
            const statusNode = document.getElementById("export-png-status");
            if (!graph || !graph.data || !window.Plotly) {
                return "PNG export failed.";
            }

            const filenames = {
                "reciprocal-space": "powder_views",
                "detector-view": "mosaic_view",
                "special-cause-reciprocal": "special_cause_reciprocal",
                "fibrous-view": "ewald_cylinder",
                "specular-view": "specular_reflection",
            };
            const exportWidth = 1800;
            const exportHeight = 1800;
            const sliderBackup = graph.layout && graph.layout.sliders
                ? JSON.parse(JSON.stringify(graph.layout.sliders))
                : [];
            const menuBackup = graph.layout && graph.layout.updatemenus
                ? JSON.parse(JSON.stringify(graph.layout.updatemenus))
                : [];
            const sceneCameraBackup = Object.fromEntries(
                Object.entries(graph.layout || {})
                    .filter(([key, value]) => /^scene\\d*$/.test(key) && value && value.camera)
                    .map(([key, value]) => [
                        key + ".camera",
                        JSON.parse(JSON.stringify(value.camera)),
                    ])
            );

            const setStatus = (message) => {
                if (statusNode) {
                    statusNode.textContent = message;
                }
                return message;
            };

            const cloneValue = (value) => JSON.parse(JSON.stringify(value));

            const restoreControls = async () => {
                await Plotly.relayout(graph, {
                    sliders: sliderBackup,
                    updatemenus: menuBackup,
                    ...sceneCameraBackup,
                });
            };

            const hideControls = async () => {
                if (!sliderBackup.length && !menuBackup.length) {
                    if (Object.keys(sceneCameraBackup).length) {
                        await Plotly.relayout(graph, sceneCameraBackup);
                    }
                    return;
                }
                await Plotly.relayout(graph, {
                    sliders: [],
                    updatemenus: [],
                    ...sceneCameraBackup,
                });
            };

            const createHiddenExportDiv = () => {
                const host = document.createElement("div");
                host.style.position = "fixed";
                host.style.left = "-10000px";
                host.style.top = "0";
                host.style.width = exportWidth + "px";
                host.style.height = exportHeight + "px";
                host.style.background = "white";
                host.style.pointerEvents = "none";
                document.body.appendChild(host);
                return host;
            };

            const cleanupHiddenExportDiv = (host) => {
                if (!host) {
                    return;
                }
                try {
                    Plotly.purge(host);
                } catch (purgeErr) {
                    console.error(purgeErr);
                }
                host.remove();
            };

            const buildPanelLayout = (titleText) => ({
                template: graph.layout?.template ? cloneValue(graph.layout.template) : undefined,
                paper_bgcolor: graph.layout?.paper_bgcolor || "white",
                plot_bgcolor: graph.layout?.plot_bgcolor || "white",
                margin: {l: 80, r: 60, b: 80, t: 120},
                title: {
                    text: titleText,
                    x: 0.5,
                    xanchor: "center",
                },
                showlegend: false,
            });

            const downloadStandaloneFigure = async (figureSpec) => {
                const host = createHiddenExportDiv();
                try {
                    await Plotly.newPlot(
                        host,
                        figureSpec.data,
                        figureSpec.layout,
                        {
                            displaylogo: false,
                            displayModeBar: false,
                            responsive: false,
                            staticPlot: true,
                        }
                    );
                    await Plotly.downloadImage(host, {
                        format: "png",
                        filename: figureSpec.filename,
                        width: exportWidth,
                        height: exportHeight,
                    });
                } finally {
                    cleanupHiddenExportDiv(host);
                }
            };

            const downloadSingleView = async (filename) => {
                try {
                    await hideControls();
                    await Plotly.downloadImage(graph, {
                        format: "png",
                        filename: filename,
                        width: exportWidth,
                        height: exportHeight,
                    });
                } catch (err) {
                    console.error(err);
                } finally {
                    try {
                        await restoreControls();
                    } catch (restoreErr) {
                        console.error(restoreErr);
                    }
                }
            };

            const downloadPowderViews = async (modes) => {
                const originalVis = (graph.data || []).map((trace) => {
                    if (trace.visible === undefined) {
                        return true;
                    }
                    return trace.visible;
                });

                setStatus("Preparing downloads...");

                try {
                    await hideControls();
                    for (const mode of modes) {
                        const vis = Array.from(mode.vis, (value) => !!value);
                        await Plotly.update(graph, {visible: vis});
                        const uri = await Plotly.toImage(graph, {
                            format: "png",
                            width: exportWidth,
                            height: exportHeight,
                        });
                        const link = document.createElement("a");
                        link.href = uri;
                        link.download = mode.filename;
                        document.body.appendChild(link);
                        link.click();
                        link.remove();
                    }
                    setStatus("Downloaded Single, 3D, 2D, and Cylinder views.");
                } catch (err) {
                    console.error(err);
                    setStatus("Download failed. Please retry.");
                } finally {
                    try {
                        await Plotly.update(graph, {visible: originalVis});
                    } catch (restoreVisErr) {
                        console.error(restoreVisErr);
                    }
                    try {
                        await restoreControls();
                    } catch (restoreControlsErr) {
                        console.error(restoreControlsErr);
                    }
                }
            };

            const downloadMosaicPanels = async () => {
                const detectorData = graph.data || [];
                const sceneCamera = graph.layout?.scene?.camera
                    ? cloneValue(graph.layout.scene.camera)
                    : null;
                const reciprocalData = detectorData
                    .filter((trace) => trace?.scene === "scene")
                    .map((trace) => cloneValue(trace));
                const detectorViewData = detectorData
                    .filter((trace) => trace?.xaxis === "x" && trace?.yaxis === "y")
                    .map((trace) => {
                        const clonedTrace = cloneValue(trace);
                        delete clonedTrace.xaxis;
                        delete clonedTrace.yaxis;
                        return clonedTrace;
                    });
                const centeredData = detectorData
                    .filter((trace) => trace?.xaxis === "x2" && trace?.yaxis === "y2")
                    .map((trace) => {
                        const clonedTrace = cloneValue(trace);
                        clonedTrace.xaxis = "x";
                        clonedTrace.yaxis = "y";
                        return clonedTrace;
                    });

                if (!reciprocalData.length || !detectorViewData.length || !centeredData.length) {
                    setStatus("Download failed. Please retry.");
                    return;
                }

                const reciprocalLayout = {
                    ...buildPanelLayout("Reciprocal space"),
                    scene: graph.layout?.scene ? cloneValue(graph.layout.scene) : {},
                    uirevision: graph.layout?.uirevision,
                };
                if (sceneCamera) {
                    reciprocalLayout.scene.camera = sceneCamera;
                }

                const detectorLayout = buildPanelLayout("Detector view");
                detectorLayout.xaxis = graph.layout?.xaxis ? cloneValue(graph.layout.xaxis) : {};
                detectorLayout.yaxis = graph.layout?.yaxis ? cloneValue(graph.layout.yaxis) : {};
                delete detectorLayout.xaxis.domain;
                delete detectorLayout.yaxis.domain;

                const centeredLayout = buildPanelLayout("Centered integration");
                centeredLayout.xaxis = graph.layout?.xaxis2 ? cloneValue(graph.layout.xaxis2) : {};
                centeredLayout.yaxis = graph.layout?.yaxis2 ? cloneValue(graph.layout.yaxis2) : {};
                delete centeredLayout.xaxis.domain;
                delete centeredLayout.yaxis.domain;

                const figures = [
                    {
                        filename: "mosaic_reciprocal_space.png",
                        data: reciprocalData,
                        layout: reciprocalLayout,
                    },
                    {
                        filename: "mosaic_detector_view.png",
                        data: detectorViewData,
                        layout: detectorLayout,
                    },
                    {
                        filename: "mosaic_centered_integration.png",
                        data: centeredData,
                        layout: centeredLayout,
                    },
                ];

                setStatus("Preparing Mosaic View downloads...");

                try {
                    for (const figureSpec of figures) {
                        await downloadStandaloneFigure(figureSpec);
                    }
                    setStatus("Downloaded reciprocal space, detector view, and centered integration.");
                } catch (err) {
                    console.error(err);
                    setStatus("Download failed. Please retry.");
                }
            };

            if (modeValue === "reciprocal-space") {
                const buttons = graph.layout && graph.layout.updatemenus && graph.layout.updatemenus.length
                    ? graph.layout.updatemenus[0].buttons || []
                    : [];
                const powderModes = [
                    {label: "Single crystal", filename: "mono_single_crystal.png"},
                    {label: "3D Powder", filename: "reciprocal_3d_powder.png"},
                    {label: "2D Powder", filename: "reciprocal_2d_powder.png"},
                    {label: "Cylinder", filename: "mono_cylinder.png"},
                ].map((mode, index) => ({
                    ...mode,
                    vis: buttons[index] && buttons[index].args && buttons[index].args.length
                        ? buttons[index].args[0].visible
                        : null,
                }));

                if (powderModes.every((mode) => Array.isArray(mode.vis))) {
                    downloadPowderViews(powderModes);
                    return "Saving mono_single_crystal.png, reciprocal_3d_powder.png, reciprocal_2d_powder.png, and mono_cylinder.png...";
                }
            }

            if (modeValue === "detector-view") {
                downloadMosaicPanels();
                return "Saving mosaic_reciprocal_space.png, mosaic_detector_view.png, and mosaic_centered_integration.png...";
            }

            const filename = filenames[modeValue] || "simulation";
            downloadSingleView(filename);
            return "Saving " + filename + ".png...";
        }
        """

SPECIAL_CAUSE_MATRIX_EXPORT_CLIENTSIDE_CALLBACK = """
        function(figureSpec) {
            const statusNode = document.getElementById("export-special-cause-matrix-status");
            const hostSelector = "[data-special-cause-matrix-export-host='true']";
            const setStatus = (message) => {
                if (statusNode) {
                    statusNode.textContent = message;
                }
                return message;
            };
            const purgeAndRemoveHost = (exportHost) => {
                try {
                    if (window.Plotly) {
                        Plotly.purge(exportHost);
                    }
                } catch (purgeErr) {
                    console.error(purgeErr);
                }
                exportHost.remove();
            };
            const cleanupExistingMatrixExports = () =>
                document.querySelectorAll(hostSelector).forEach(purgeAndRemoveHost);

            if (!figureSpec) {
                return window.dash_clientside.no_update;
            }
            window.__specialCauseMatrixExportRequest = (window.__specialCauseMatrixExportRequest || 0) + 1;
            const requestId = window.__specialCauseMatrixExportRequest;
            const ignoreStaleRequest = () => {
                const currentMatrixExportRequest = window.__specialCauseMatrixExportRequest;
                return requestId !== currentMatrixExportRequest;
            };
            cleanupExistingMatrixExports();
            if (figureSpec.error) {
                return setStatus("Matrix export failed: " + figureSpec.error);
            }
            if (!figureSpec.data || !figureSpec.layout || !window.Plotly) {
                return setStatus("Matrix export failed.");
            }

            const exportWidth = 1800;
            const exportHeight = 1800;
            const host = document.createElement("div");
            host.dataset.specialCauseMatrixExportHost = "true";
            host.style.position = "fixed";
            host.style.left = "-10000px";
            host.style.top = "0";
            host.style.width = exportWidth + "px";
            host.style.height = exportHeight + "px";
            host.style.background = "white";
            host.style.pointerEvents = "none";
            document.body.appendChild(host);

            const downloadMatrix = async () => {
                try {
                    await Plotly.newPlot(
                        host,
                        figureSpec.data,
                        figureSpec.layout,
                        {
                            displaylogo: false,
                            displayModeBar: false,
                            responsive: false,
                            staticPlot: true,
                        }
                    );
                    await Plotly.downloadImage(host, {
                        format: "png",
                        filename: "special_cause_reciprocal_matrix",
                        width: exportWidth,
                        height: exportHeight,
                    });
                    if (ignoreStaleRequest()) {
                        return;
                    }
                    setStatus("Downloaded special_cause_reciprocal_matrix.png.");
                } catch (err) {
                    console.error(err);
                    if (ignoreStaleRequest()) {
                        return;
                    }
                    setStatus("Matrix export failed. Please retry.");
                } finally {
                    purgeAndRemoveHost(host);
                }
            };

            downloadMatrix();
            return "Saving special_cause_reciprocal_matrix.png...";
        }
        """

POWDER_QR_CLIENTSIDE_CALLBACK = """
        function(modeValue, figureValue, selectionState, powderViewValue) {
            if (modeValue !== "reciprocal-space") {
                return window.dash_clientside.no_update;
            }

            const graphContainer = document.getElementById("simulation-figure");
            const graph = graphContainer?.querySelector?.(".js-plotly-plot") || graphContainer;
            if (!graph || !graph.data || !graph.layout || !window.Plotly) {
                return window.dash_clientside.no_update;
            }

            const menus = graph.layout.updatemenus
                ? JSON.parse(JSON.stringify(graph.layout.updatemenus))
                : [];
            if (!menus.length || !menus[0].buttons || menus[0].buttons.length < 4) {
                return window.dash_clientside.no_update;
            }

            const meta = graph.layout.meta || {};
            const sphereGroups = Array.isArray(meta.g_group_indices) ? meta.g_group_indices : [];
            const ringGroups = Array.isArray(meta.g_ring_groups) ? meta.g_ring_groups : [];
            const cylinderGroups = Array.isArray(meta.g_cylinder_group_indices)
                ? meta.g_cylinder_group_indices
                : [];

            const oldSingleVis = menus[0].buttons[0]?.args?.[0]?.visible;
            const oldSphereVis = menus[0].buttons[1]?.args?.[0]?.visible;
            const oldRingVis = menus[0].buttons[2]?.args?.[0]?.visible;
            const oldCylinderVis = menus[0].buttons[3]?.args?.[0]?.visible;
            if (!Array.isArray(oldSingleVis) || !Array.isArray(oldSphereVis) || !Array.isArray(oldRingVis) || !Array.isArray(oldCylinderVis)) {
                return window.dash_clientside.no_update;
            }

            const cloneCamera = () => {
                const camera = graph.layout?.scene?.camera;
                return camera ? JSON.parse(JSON.stringify(camera)) : null;
            };

            const normalizeSelection = (rawValue, count, defaultValue) => {
                const value = rawValue === null || rawValue === undefined ? defaultValue : rawValue;
                const items = Array.isArray(value) ? value : [value];
                const seen = new Set();
                const normalized = [];
                items.forEach((item) => {
                    const index = Number.parseInt(item, 10);
                    if (Number.isInteger(index) && index >= 0 && index < count && !seen.has(index)) {
                        seen.add(index);
                        normalized.push(index);
                    }
                });
                return normalized;
            };

            const setGroupVisibility = (visibleArray, groups, selected) => {
                const selectedIndices = new Set(selected);
                groups.forEach((group, index) => {
                    const enabled = selectedIndices.has(index);
                    group.forEach((traceIndex) => {
                        visibleArray[traceIndex] = enabled;
                    });
                });
            };

            const arraysEqual = (left, right) =>
                Array.isArray(left) &&
                Array.isArray(right) &&
                left.length === right.length &&
                left.every((value, index) => !!value === !!right[index]);

            const currentVis = (graph.data || []).map((trace) =>
                trace && trace.visible === undefined ? true : !!trace.visible
            );

            const sphereSelection = normalizeSelection(
                selectionState?.sphere_selection,
                sphereGroups.length,
                sphereGroups.length ? [0] : []
            );
            const ringSelection = normalizeSelection(
                selectionState?.ring_selection,
                ringGroups.length,
                ringGroups.map((_, index) => index)
            );
            const cylinderSelection = normalizeSelection(
                selectionState?.cylinder_selection,
                cylinderGroups.length,
                cylinderGroups.length ? [0] : []
            );
            const resolvedPowderView = [
                "single-crystal",
                "3d-powder",
                "2d-powder",
                "cylinder",
            ].includes(powderViewValue)
                ? powderViewValue
                : "single-crystal";

            const nextSphereVis = Array.from(oldSphereVis, (value) => !!value);
            const nextRingVis = Array.from(oldRingVis, (value) => !!value);
            const nextCylinderVis = Array.from(oldCylinderVis, (value) => !!value);
            setGroupVisibility(nextSphereVis, sphereGroups, sphereSelection);
            setGroupVisibility(nextRingVis, ringGroups, ringSelection);
            setGroupVisibility(nextCylinderVis, cylinderGroups, cylinderSelection);

            menus[0].visible = false;
            menus[0].active = {
                "single-crystal": 0,
                "3d-powder": 1,
                "2d-powder": 2,
                "cylinder": 3,
            }[resolvedPowderView] ?? 0;
            menus[0].buttons[1].args[0].visible = nextSphereVis;
            menus[0].buttons[2].args[0].visible = nextRingVis;
            menus[0].buttons[3].args[0].visible = nextCylinderVis;

            const targetVis = {
                "single-crystal": Array.from(oldSingleVis, (value) => !!value),
                "3d-powder": nextSphereVis,
                "2d-powder": nextRingVis,
                "cylinder": nextCylinderVis,
            }[resolvedPowderView];

            const layoutUpdate = { updatemenus: menus };
            const camera = cloneCamera();
            if (camera) {
                layoutUpdate["scene.camera"] = camera;
            }

            const updateFigure = (visibleArray) =>
                Plotly.update(graph, {visible: visibleArray}, layoutUpdate)
                    .catch((error) => console.error(error));

            const relayoutFigure = () =>
                Plotly.relayout(graph, layoutUpdate)
                    .catch((error) => console.error(error));

            if (arraysEqual(currentVis, targetVis)) {
                relayoutFigure();
            } else {
                updateFigure(targetVis);
            }

            return {
                active_view: resolvedPowderView,
                sphere_selection: sphereSelection,
                ring_selection: ringSelection,
                cylinder_selection: cylinderSelection,
                synced_at: Date.now(),
            };
        }
        """


@dataclass(frozen=True)
class ControlSpec:
    key: str
    label: Any
    component: str
    default: Any
    step: float | int | None = None
    min: float | None = None
    max: float | None = None
    options: tuple[tuple[str, Any], ...] = ()
    input_step: float | int | str | None = None
    updatemode: str | None = None


@dataclass(frozen=True)
class SimulationSpec:
    key: str
    label: str
    description: str
    controls: tuple[ControlSpec, ...]
    build_figure: Callable[[dict[str, Any]], go.Figure]


def _message_figure(title: str, message: str) -> go.Figure:
    fig = go.Figure()
    fig.add_annotation(
        text=message,
        x=0.5,
        y=0.5,
        xref="paper",
        yref="paper",
        showarrow=False,
        font=dict(size=18, color="crimson"),
    )
    fig.update_xaxes(visible=False)
    fig.update_yaxes(visible=False)
    fig.update_layout(
        title=title,
        margin=dict(l=40, r=40, b=40, t=80),
        paper_bgcolor="white",
        plot_bgcolor="white",
    )
    return fig


def _hkl_controls(
    *,
    hybrid_mosaic_params: bool = False,
    default_L: int = 12,
    default_wavelength_bandwidth_pct: float = 0.0,
) -> tuple[ControlSpec, ...]:
    base_controls = (
        ControlSpec("H", "H", "number", 0, step=1),
        ControlSpec("K", "K", "number", 0, step=1),
        ControlSpec("L", "L", "number", default_L, step=1),
    )
    if hybrid_mosaic_params:
        return base_controls + (
            ControlSpec(
                "sigma_deg",
                "σ (deg)",
                "slider_input",
                0.8,
                step=0.05,
                min=0.05,
                max=10.0,
                input_step=0.05,
            ),
            ControlSpec(
                "Gamma_deg",
                "Γ (deg)",
                "slider_input",
                5.0,
                step=0.1,
                min=0.1,
                max=30.0,
                input_step=0.1,
            ),
            ControlSpec(
                "eta",
                "η",
                "slider_input",
                0.5,
                step=0.01,
                min=0.0,
                max=1.0,
                input_step=0.01,
            ),
            ControlSpec(
                "wavelength_bandwidth_pct",
                "λ bandwidth (%)",
                "slider_input",
                default_wavelength_bandwidth_pct,
                step=0.01,
                min=0.0,
                max=WAVELENGTH_BANDWIDTH_CONTROL_MAX_PCT,
                input_step=0.01,
            ),
        )
    return base_controls + (
        ControlSpec("sigma_deg", "σ (deg)", "number", 0.8, step=0.1, min=0.0),
        ControlSpec("Gamma_deg", "Γ (deg)", "number", 5.0, step=0.1, min=0.0),
        ControlSpec("eta", "η", "number", 0.5, step=0.05, min=0.0, max=1.0),
        ControlSpec(
            "wavelength_bandwidth_pct",
            "λ bandwidth (%)",
            "number",
            default_wavelength_bandwidth_pct,
            step=0.01,
            min=0.0,
            max=WAVELENGTH_BANDWIDTH_CONTROL_MAX_PCT,
        ),
    )


def _mosaic_theta_hkl_controls(
    *,
    default_theta_i_deg: float = DEFAULT_THETA_DEG,
    default_L: int = 12,
    default_wavelength_bandwidth_pct: float = 0.0,
) -> tuple[ControlSpec, ...]:
    return (
        ControlSpec(
            "theta_i_deg",
            "θᵢ (deg)",
            "slider",
            default_theta_i_deg,
            step=0.25,
            min=THETA_MIN_DEG,
            max=THETA_MAX_DEG,
        ),
        *_hkl_controls(
            hybrid_mosaic_params=True,
            default_L=default_L,
            default_wavelength_bandwidth_pct=default_wavelength_bandwidth_pct,
        ),
    )


def _special_cause_reciprocal_controls() -> tuple[ControlSpec, ...]:
    controls = _mosaic_theta_hkl_controls(
        default_theta_i_deg=SPECIAL_CAUSE_DEFAULT_THETA_I_DEG,
        default_L=SPECIAL_CAUSE_DEFAULT_L,
        default_wavelength_bandwidth_pct=SPECIAL_CAUSE_DEFAULT_WAVELENGTH_BANDWIDTH_PCT,
    )
    theta_control = replace(
        controls[0],
        component="slider_input",
        input_step="any",
        updatemode="drag",
    )
    return (
        theta_control,
        *controls[1:],
        ControlSpec(
            "center_bragg_only",
            "Hide Ewald + angle helpers",
            "checklist",
            False,
        ),
        ControlSpec(
            "ewald_shell_sample_count",
            "Ewald samples (odd)",
            "number",
            SPECIAL_CAUSE_DEFAULT_EWALD_SHELL_SAMPLE_COUNT,
            step=2,
            min=SPECIAL_CAUSE_MIN_EWALD_SHELL_SAMPLE_COUNT,
            max=SPECIAL_CAUSE_MAX_EWALD_SHELL_SAMPLE_COUNT,
        ),
    )


_MOSAIC_CONTROL_SECTIONS = (
    ("Incident Angle", ("theta_i_deg",)),
    ("Reflection", ("H", "K", "L")),
    ("Mosaic Envelope", ("sigma_deg", "Gamma_deg", "eta", "wavelength_bandwidth_pct")),
)
_SPECIAL_CAUSE_CONTROL_SECTIONS = (
    ("Incident Angle", ("theta_i_deg", "center_bragg_only")),
    ("Reflection", ("H", "K", "L")),
    ("Mosaic Envelope", ("sigma_deg", "Gamma_deg", "eta", "wavelength_bandwidth_pct")),
    ("Ewald Sampling", ("ewald_shell_sample_count",)),
)
_CHECKLIST_CONTROL_KEYS = frozenset({"center_bragg_only"})


@lru_cache(maxsize=1)
def _specular_control_sections() -> tuple[tuple[str, tuple[ControlSpec, ...]], ...]:
    default_by_group = {
        "beam": SpecularBeamConfig(),
        "sample": SpecularSampleConfig(),
        "detector": SpecularDetectorConfig(),
        "diffraction": SpecularDiffractionConfig(),
    }
    sections: list[tuple[str, tuple[ControlSpec, ...]]] = []
    for title, controls in SPECULAR_CONTROL_SECTIONS:
        unified_controls = tuple(
            ControlSpec(
                key=control.name,
                label=control.label,
                component="slider_input",
                default=getattr(default_by_group[control.config_group], control.attr_name),
                step=control.step,
                min=control.min_value,
                max=control.max_value,
                input_step=control.step,
                updatemode=control.updatemode,
            )
            for control in controls
        )
        sections.append((title, unified_controls))
    return tuple(sections)


def _specular_controls() -> tuple[ControlSpec, ...]:
    return tuple(
        control
        for _, section_controls in _specular_control_sections()
        for control in section_controls
    )


def _mode_state_from_spec(spec: SimulationSpec) -> dict[str, Any]:
    return {control.key: control.default for control in spec.controls}


def _default_state() -> dict[str, dict[str, Any]]:
    return {key: _mode_state_from_spec(spec) for key, spec in SIMULATION_SPECS.items()}


def _seeded_state(
    initial_state: dict[str, dict[str, Any]] | None = None,
) -> dict[str, dict[str, Any]]:
    state = _default_state()
    if not isinstance(initial_state, dict):
        return state
    for mode_key, mode_state in initial_state.items():
        if mode_key not in state or not isinstance(mode_state, dict):
            continue
        seeded = dict(state[mode_key])
        seeded.update(mode_state)
        state[mode_key] = seeded
    return state


def _resolve_mode(mode: str | None) -> str:
    if mode in SIMULATION_SPECS:
        return str(mode)
    return DEFAULT_MODE


def _merged_mode_state(mode: str, state: dict[str, Any] | None = None) -> dict[str, Any]:
    spec = SIMULATION_SPECS[mode]
    merged = _mode_state_from_spec(spec)
    if state:
        merged.update(dict(state))
    return merged


def _updated_mode_state(
    mode_value: Any,
    values: list[Any],
    hybrid_values: list[Any],
    control_ids: list[dict[str, Any]],
    hybrid_ids: list[dict[str, Any]],
    state_value: dict[str, Any] | None,
    triggered_id: Any,
) -> dict[str, dict[str, Any]] | None:
    mode_key = _resolve_mode(mode_value)
    current_state = dict(state_value or {})
    previous_mode_state = _merged_mode_state(mode_key, current_state.get(mode_key))
    mode_state = dict(previous_mode_state)

    if isinstance(triggered_id, dict):
        pairs: list[tuple[dict[str, Any], Any]]
        if triggered_id.get("type") == "simulation-control":
            pairs = list(zip(control_ids, values, strict=True))
        elif triggered_id.get("type") == "simulation-hybrid-input":
            pairs = list(zip(hybrid_ids, hybrid_values, strict=True))
        else:
            pairs = []
        for control_id, value in pairs:
            if control_id["key"] == triggered_id.get("key"):
                mode_state[control_id["key"]] = _normalize_control_state_value(control_id["key"], value)
                break
    else:
        for control_id, value in zip(control_ids, values, strict=True):
            mode_state[control_id["key"]] = _normalize_control_state_value(control_id["key"], value)
        for control_id, value in zip(hybrid_ids, hybrid_values, strict=True):
            mode_state[control_id["key"]] = value

    if mode_state == previous_mode_state:
        return None

    next_state = dict(current_state)
    next_state[mode_key] = mode_state
    if next_state == current_state:
        return None
    return next_state


def _normalize_control_state_value(control_key: str, value: Any) -> Any:
    if control_key in _CHECKLIST_CONTROL_KEYS:
        return bool(value)
    return value


def _normalize_hkl_mosaic_values(values: dict[str, Any]) -> tuple[int, int, int, float, float, float]:
    return normalize_detector_params(
        values.get("H"),
        values.get("K"),
        values.get("L"),
        values.get("sigma_deg"),
        values.get("Gamma_deg", values.get("gamma_deg")),
        values.get("eta"),
    )


def _build_reciprocal_space_figure(values: dict[str, Any]) -> go.Figure:
    theta_min_deg = float(values.get("theta_i_min_deg", values.get("theta_min_deg", 0.0)))
    theta_max_deg = float(values.get("theta_i_max_deg", values.get("theta_max_deg", 90.0)))
    frames = int(values.get("frames", N_FRAMES_DEFAULT))
    render_profile = str(values.get("render_profile", "balanced"))

    if frames < 2:
        return _message_figure("Powder Views", "frames must be at least 2")
    if theta_max_deg <= theta_min_deg:
        return _message_figure(
            "Powder Views",
            "θᵢ max must be greater than θᵢ min",
        )

    try:
        fig, _ = build_mono_figure(
            math.radians(theta_min_deg),
            math.radians(theta_max_deg),
            frames,
            render_profile=render_profile,
        )
    except ValueError as exc:
        return _message_figure("Powder Views", str(exc))
    if fig.layout.updatemenus:
        fig.layout.updatemenus[0].visible = False
    return fig


def _build_detector_adapter(values: dict[str, Any]) -> go.Figure:
    try:
        params = _normalize_hkl_mosaic_values(values)
        theta_deg = float(values.get("theta_i_deg", values.get("theta_deg", DEFAULT_THETA_DEG)))
        return build_detector_figure(
            *params,
            wavelength_bandwidth_pct=values.get("wavelength_bandwidth_pct"),
            theta_i=math.radians(theta_deg),
        )
    except ValueError as exc:
        return _message_figure("Mosaic View", str(exc))


def _build_special_cause_reciprocal_adapter(values: dict[str, Any]) -> go.Figure:
    try:
        params = _normalize_hkl_mosaic_values(values)
        theta_deg = float(values.get("theta_i_deg", values.get("theta_deg", DEFAULT_THETA_DEG)))
        return build_special_cause_reciprocal_figure(
            *params,
            wavelength_bandwidth_pct=values.get("wavelength_bandwidth_pct"),
            ewald_shell_sample_count=values.get("ewald_shell_sample_count"),
            theta_i=math.radians(theta_deg),
            center_bragg_only=bool(values.get("center_bragg_only", False)),
        )
    except ValueError as exc:
        return _message_figure("Special Cause Reciprocal", str(exc))


def _scene_name_for_matrix_cell(row: int, col: int) -> str:
    scene_index = (row - 1) * len(SPECIAL_CAUSE_MATRIX_THETA_DEG) + col
    return "scene" if scene_index == 1 else f"scene{scene_index}"


def _build_special_cause_matrix_cell(values: dict[str, Any], *, L: int, theta_deg: float) -> go.Figure:
    cell_values = dict(values)
    cell_values.update({"H": 0, "K": 0, "L": L})
    params = _normalize_hkl_mosaic_values(cell_values)
    return build_special_cause_reciprocal_figure(
        *params,
        wavelength_bandwidth_pct=cell_values.get("wavelength_bandwidth_pct"),
        ewald_shell_sample_count=cell_values.get("ewald_shell_sample_count"),
        theta_i=math.radians(theta_deg),
        center_bragg_only=bool(cell_values.get("center_bragg_only", False)),
    )


def _build_special_cause_matrix_figure(
    values: dict[str, Any],
    *,
    camera: dict[str, Any] | None = None,
) -> go.Figure:
    """Return a fixed 3x3 special-cause reciprocal comparison figure."""

    fig = make_subplots(
        rows=len(SPECIAL_CAUSE_MATRIX_L_VALUES),
        cols=len(SPECIAL_CAUSE_MATRIX_THETA_DEG),
        specs=[
            [{"type": "scene"} for _ in SPECIAL_CAUSE_MATRIX_THETA_DEG]
            for _ in SPECIAL_CAUSE_MATRIX_L_VALUES
        ],
        column_titles=[f"θᵢ = {theta:g}°" for theta in SPECIAL_CAUSE_MATRIX_THETA_DEG],
        horizontal_spacing=0.01,
        vertical_spacing=0.03,
    )

    hide_export_helpers = bool(values.get("center_bragg_only", False))
    for row, L in enumerate(SPECIAL_CAUSE_MATRIX_L_VALUES, start=1):
        for col, theta_deg in enumerate(SPECIAL_CAUSE_MATRIX_THETA_DEG, start=1):
            cell_fig = _build_special_cause_matrix_cell(values, L=L, theta_deg=theta_deg)
            show_cell_colorbar = row == 1 and col == 1
            for trace in cell_fig.data:
                trace_copy = copy.deepcopy(trace)
                if hide_export_helpers and getattr(trace_copy, "name", "") == "Bragg/Ewald overlap band":
                    continue
                if getattr(trace_copy, "name", "") == "Bragg sphere":
                    trace_copy.showscale = show_cell_colorbar
                    trace_copy.cmin = 0.0
                    trace_copy.cmax = 1.0
                    if show_cell_colorbar:
                        trace_copy.colorbar = dict(
                            title="Mosaic<br>Intensity",
                            x=1.02,
                            len=0.72,
                        )
                fig.add_trace(trace_copy, row=row, col=col)

            scene_name = _scene_name_for_matrix_cell(row, col)
            scene_layout = cell_fig.layout.scene.to_plotly_json()
            if camera:
                scene_layout["camera"] = camera
            fig.update_layout({scene_name: scene_layout})

    for row, L in enumerate(SPECIAL_CAUSE_MATRIX_L_VALUES, start=1):
        scene_layout = getattr(fig.layout, _scene_name_for_matrix_cell(row, 1))
        y_domain = scene_layout.domain.y
        fig.add_annotation(
            text=f"L = {L}",
            x=-0.03,
            y=(float(y_domain[0]) + float(y_domain[1])) / 2.0,
            xref="paper",
            yref="paper",
            showarrow=False,
            textangle=-90,
            xanchor="center",
            yanchor="middle",
            font=dict(size=16, color="#2d4363"),
        )

    fig.update_layout(
        title=dict(
            text="Special Cause Reciprocal Matrix",
            x=0.5,
            xanchor="center",
        ),
        showlegend=False,
        paper_bgcolor="white",
        plot_bgcolor="white",
        margin=dict(l=90, r=90, b=24, t=88),
        width=SPECIAL_CAUSE_MATRIX_EXPORT_SIZE_PX,
        height=SPECIAL_CAUSE_MATRIX_EXPORT_SIZE_PX,
    )
    return fig


def _build_fibrous_adapter(values: dict[str, Any]) -> go.Figure:
    try:
        params = normalize_cylinder_params(
            values.get("H"),
            values.get("K"),
            values.get("L"),
            values.get("sigma_deg"),
            values.get("Gamma_deg", values.get("gamma_deg")),
            values.get("eta"),
        )
        return build_cylinder_figure(
            *params,
            wavelength_bandwidth_pct=values.get("wavelength_bandwidth_pct"),
        )
    except ValueError as exc:
        return _message_figure("Ewald Cylinder", str(exc))


def _resolve_specular_configs(
    values: dict[str, Any],
) -> tuple[SpecularBeamConfig, SpecularSampleConfig, SpecularDetectorConfig, SpecularDiffractionConfig]:
    return specular_configs_from_values(
        rays=values.get("rays"),
        seed=values.get("seed"),
        display_rays=values.get("display_rays"),
        source_y=values.get("source_y"),
        beam_width_x=values.get("beam_width_x"),
        beam_width_z=values.get("beam_width_z"),
        divergence_x=values.get("divergence_x"),
        divergence_z=values.get("divergence_z"),
        z_beam=values.get("z_beam"),
        sample_width=values.get("sample_width"),
        sample_height=values.get("sample_height"),
        theta_i=values.get("theta_i"),
        delta=values.get("delta"),
        alpha=values.get("alpha"),
        psi=values.get("psi"),
        z_sample=values.get("z_sample"),
        distance=values.get("distance"),
        detector_width=values.get("detector_width"),
        detector_height=values.get("detector_height"),
        beta=values.get("beta"),
        gamma=values.get("gamma"),
        chi=values.get("chi"),
        pixel_u=values.get("pixel_u"),
        pixel_v=values.get("pixel_v"),
        i0=values.get("i0"),
        j0=values.get("j0"),
        h_index=values.get("H"),
        k_index=values.get("K"),
        l_index=values.get("L"),
        sigma_deg=values.get("sigma_deg"),
        mosaic_gamma_deg=values.get("mosaic_gamma_deg"),
        eta=values.get("eta"),
        wavelength_m=values.get("wavelength_m"),
        lattice_a_m=values.get("lattice_a_m"),
        lattice_c_m=values.get("lattice_c_m"),
        default_beam=SpecularBeamConfig(),
        default_sample=SpecularSampleConfig(),
        default_detector=SpecularDetectorConfig(),
        default_diffraction=SpecularDiffractionConfig(),
    )


def _build_specular_dashboard_adapter(
    values: dict[str, Any],
    *,
    camera: dict[str, Any] | None = None,
    companion_camera: dict[str, Any] | None = None,
) -> tuple[go.Figure, go.Figure, str]:
    try:
        beam_config, sample_config, detector_config, diffraction_config = _resolve_specular_configs(values)
    except ValueError as exc:
        summary = f"Error: {exc}"
        figure = build_specular_error_figure(str(exc))
        figure.update_layout(meta={"simulation_summary": summary})
        companion_figure = build_specular_companion_error_figure(str(exc))
        return figure, companion_figure, summary

    figure, companion_figure, summary = build_specular_dashboard_views(
        beam_config,
        sample_config,
        detector_config,
        diffraction_config,
        camera=camera,
        companion_camera=companion_camera,
    )
    meta = dict(figure.layout.meta) if isinstance(figure.layout.meta, dict) else {}
    meta["simulation_summary"] = summary
    figure.update_layout(meta=meta)
    return figure, companion_figure, summary


def _build_specular_main_adapter(
    values: dict[str, Any],
    *,
    camera: dict[str, Any] | None = None,
) -> tuple[go.Figure, str]:
    try:
        beam_config, sample_config, detector_config, diffraction_config = _resolve_specular_configs(values)
    except ValueError as exc:
        summary = f"Error: {exc}"
        figure = build_specular_error_figure(str(exc))
        figure.update_layout(meta={"simulation_summary": summary})
        return figure, summary

    figure, summary = build_specular_outputs(
        beam_config,
        sample_config,
        detector_config,
        diffraction_config,
        camera=camera,
    )
    figure = set_figure_meta_value(figure, "simulation_summary", summary)
    return figure, summary


def _build_specular_companion_adapter(
    values: dict[str, Any],
    *,
    camera: dict[str, Any] | None = None,
) -> go.Figure:
    try:
        _, sample_config, _, diffraction_config = _resolve_specular_configs(values)
    except ValueError as exc:
        return build_specular_companion_error_figure(str(exc))
    return build_specular_companion_figure(
        sample_config,
        diffraction_config,
        camera=camera,
    )


def _build_specular_summary_adapter(values: dict[str, Any]) -> str:
    try:
        beam_config, sample_config, detector_config, diffraction_config = _resolve_specular_configs(values)
    except ValueError as exc:
        return f"Error: {exc}"
    return build_specular_summary_output(
        beam_config,
        sample_config,
        detector_config,
        diffraction_config,
    )


def _build_simulation_outputs(
    mode: str,
    values: dict[str, Any],
    *,
    camera: dict[str, Any] | None = None,
) -> tuple[go.Figure, str]:
    if mode == SPECULAR_MODE:
        return _build_specular_main_adapter(values, camera=camera)

    spec = SIMULATION_SPECS[mode]
    figure = spec.build_figure(values)
    if camera and mode in SCENE_CAMERA_MODES:
        figure.update_layout(scene_camera=camera)
    return figure, ""


def _summary_style(mode: str, summary: str = "") -> dict[str, Any]:
    if mode != SPECULAR_MODE or not summary:
        return {"display": "none"}
    return {}


def _specular_companion_style(mode: str) -> dict[str, Any]:
    style = {"display": "grid", "gap": "0.75rem", "minHeight": "0"}
    if mode != SPECULAR_MODE:
        style["display"] = "none"
    return style


def _special_cause_matrix_export_style(mode: str) -> dict[str, Any]:
    if mode == SPECIAL_CAUSE_RECIPROCAL_MODE:
        return {}
    return {"display": "none"}


def _specular_companion_camera_key(mode: str) -> str:
    return f"{mode}:companion"


def _shell_class_names(mode: str) -> tuple[str, str]:
    shell_class = "simulation-shell"
    sidebar_class = "simulation-sidebar"
    if mode == SPECULAR_MODE:
        shell_class += " simulation-shell--specular"
        sidebar_class += " simulation-sidebar--specular"
    return shell_class, sidebar_class


def _main_visual_copy(mode: str) -> tuple[str, str]:
    if mode == SPECULAR_MODE:
        return (
            "Specular Geometry",
            "Lab-frame beam, sample footprint, and detector-hit geometry for the active specular configuration.",
        )
    if mode == "detector-view":
        return (
            "Mosaic Detector View",
            "Reciprocal-space geometry, detector intensity, and centered integration for the current HKL and incidence angle.",
        )
    if mode == SPECIAL_CAUSE_RECIPROCAL_MODE:
        return (
            "Special Cause Reciprocal",
            "One-panel physical reciprocal-space view using the Cu-Kα Ewald sphere and Bi2Se3 Bragg sphere for the current HKL.",
        )
    if mode == "fibrous-view":
        return (
            "Ewald Cylinder View",
            "Bragg sphere, Ewald sphere, and reciprocal cylinder overlap for the active fibrous configuration.",
        )
    return (
        "Reciprocal Space View",
        "Single-crystal, powder, and cylinder reciprocal-space views with peak filtering and an in-figure incidence sweep.",
    )


@lru_cache(maxsize=1)
def _specular_control_lookup() -> dict[str, ControlSpec]:
    return {control.key: control for control in _specular_controls()}


def _build_specular_control_sections(values: dict[str, Any]) -> list[Any]:
    control_lookup = _specular_control_lookup()
    advanced_descriptions = {
        "Sample Geometry": "Finite sample size and extra substrate rotations beyond the main incidence sweep.",
        "Beam Model": "Ray sampling, divergence, and beam footprint controls for the incident bundle.",
        "Detector Geometry": "Distance, panel size, tilts, and pixel calibration for the receiving detector.",
    }

    def control_component(control_name: str):
        control = control_lookup[control_name]
        return _build_control(control, values[control.key])

    def labeled_group(title: str, names: tuple[str, ...]) -> html.Div:
        return html.Div(
            [
                html.Div(title, className="specular-control-group-label"),
                html.Div(
                    [control_component(name) for name in names],
                    className="specular-basic-grid",
                ),
            ],
            className="specular-control-group",
        )

    basic_card = html.Section(
        [
            html.Div(
                [
                    html.Div("Basic Controls", className="specular-card-eyebrow"),
                    html.H3(
                        "Start With the Reflection",
                        className="specular-section-title",
                        style={"margin": "0"},
                    ),
                    html.Div(
                        "Keep θi and the reflection family visible. Open Advanced only when you need beam, sample, or detector alignment controls.",
                        className="specular-card-description",
                    ),
                ],
                className="specular-control-card-header",
            ),
            html.Div(
                [control_component("theta_i")],
                className="specular-basic-grid specular-basic-grid--single",
            ),
            labeled_group("Reflection", ("H", "K", "L")),
            labeled_group("Mosaic Envelope", ("sigma_deg", "mosaic_gamma_deg", "eta")),
        ],
        id="simulation-specular-basic-card",
        className="specular-control-card specular-control-card--basic",
    )

    advanced_cards = html.Div(
        [
            html.Details(
                [
                    html.Summary(
                        [
                            html.Div(title, className="specular-advanced-title"),
                            html.Div(
                                advanced_descriptions[title],
                                className="specular-advanced-description",
                            ),
                        ],
                        className="specular-advanced-summary",
                    ),
                    html.Div(
                        [control_component(name) for name in control_names],
                        className="specular-advanced-grid",
                    ),
                ],
                id=f"simulation-specular-advanced-{title.lower().replace(' ', '-')}",
                className="specular-advanced-card",
                open=False,
            )
            for title, control_names in SPECULAR_ADVANCED_CONTROL_SECTIONS
        ],
        id="simulation-specular-advanced-sections",
        className="specular-advanced-stack",
    )
    return [basic_card, advanced_cards]


def _format_ring_selector_label(g_r_value: float, g_z_value: float) -> str:
    if math.isclose(g_r_value, 0.0, abs_tol=1e-9):
        return f"00L peak, Gz ~= {g_z_value:.3f} A^-1"
    return f"Qr ~= {g_r_value:.3f} A^-1, Gz ~= {g_z_value:.3f} A^-1"


def _format_sphere_selector_label(g_value: float, two_theta_value: str) -> str:
    return f"|G| ~= {g_value:.3f} A^-1, 2θ ~= {two_theta_value}"


def _format_cylinder_selector_label(g_r_value: float) -> str:
    return f"Qr ~= {g_r_value:.3f} A^-1"


def _resolved_powder_view(value: Any) -> str:
    if value in {"single-crystal", "3d-powder", "2d-powder", "cylinder"}:
        return str(value)
    return DEFAULT_POWDER_VIEW


@lru_cache(maxsize=1)
def _powder_selector_catalog() -> dict[str, Any]:
    _, context = build_mono_figure(n_frames=2, render_profile="balanced")
    sphere_options = tuple(
        (_format_sphere_selector_label(g_value, two_theta_value), index)
        for index, (g_value, two_theta_value) in enumerate(
            zip(context["g_values"], context["g_two_thetas"], strict=True)
        )
    )
    ring_options = tuple(
        (_format_ring_selector_label(g_r_value, g_z_value), index)
        for index, (g_r_value, g_z_value) in enumerate(context["g_ring_specs"])
    )
    cylinder_options = tuple(
        (_format_cylinder_selector_label(g_r_value), index)
        for index, g_r_value in enumerate(context["g_cylinder_specs"])
    )
    return {
        "sphere_options": sphere_options,
        "ring_options": ring_options,
        "cylinder_options": cylinder_options,
        "sphere_default": (0,) if sphere_options else (),
        "ring_default": tuple(index for index, _ in enumerate(ring_options)),
        "cylinder_default": (0,) if cylinder_options else (),
    }


def _normalize_powder_selection(
    value: Any,
    option_count: int,
    default: tuple[int, ...],
) -> list[int]:
    if value is None:
        candidates = list(default)
    elif isinstance(value, (list, tuple, set)):
        candidates = list(value)
    else:
        candidates = [value]

    normalized: list[int] = []
    for raw_value in candidates:
        try:
            index = int(raw_value)
        except (TypeError, ValueError):
            continue
        if index < 0 or index >= option_count or index in normalized:
            continue
        normalized.append(index)
    return normalized


def _default_powder_selection_state() -> dict[str, list[int]]:
    catalog = _powder_selector_catalog()
    return {
        POWDER_SPHERE_SELECTION_KEY: list(catalog["sphere_default"]),
        POWDER_RING_SELECTION_KEY: list(catalog["ring_default"]),
        POWDER_CYLINDER_SELECTION_KEY: list(catalog["cylinder_default"]),
    }


def _resolved_powder_selection_state(state: dict[str, Any] | None = None) -> dict[str, list[int]]:
    catalog = _powder_selector_catalog()
    source = dict(state or {})
    return {
        POWDER_SPHERE_SELECTION_KEY: _normalize_powder_selection(
            source.get(POWDER_SPHERE_SELECTION_KEY),
            len(catalog["sphere_options"]),
            catalog["sphere_default"],
        ),
        POWDER_RING_SELECTION_KEY: _normalize_powder_selection(
            source.get(POWDER_RING_SELECTION_KEY),
            len(catalog["ring_options"]),
            catalog["ring_default"],
        ),
        POWDER_CYLINDER_SELECTION_KEY: _normalize_powder_selection(
            source.get(POWDER_CYLINDER_SELECTION_KEY),
            len(catalog["cylinder_options"]),
            catalog["cylinder_default"],
        ),
    }


def _updated_powder_view(value: Any, current_value: Any) -> str | None:
    resolved_current = _resolved_powder_view(current_value)
    resolved_value = _resolved_powder_view(value if value is not None else current_value)
    if resolved_value == resolved_current:
        return None
    return resolved_value


def _updated_powder_selection_state(
    values: list[Any],
    control_ids: list[dict[str, Any]],
    state_value: dict[str, Any] | None,
) -> dict[str, list[int]] | None:
    current_state = _resolved_powder_selection_state(state_value)
    selection_state = dict(current_state)
    for control_id, value in zip(control_ids, values, strict=True):
        selection_state[control_id["key"]] = value
    resolved_state = _resolved_powder_selection_state(selection_state)
    if resolved_state == current_state:
        return None
    return resolved_state


def _build_powder_view_control(active_view: Any = None) -> html.Div:
    resolved_view = _resolved_powder_view(active_view)
    return html.Div(
        [
            html.Label("Powder view", className="simulation-powder-label"),
            dcc.RadioItems(
                id="powder-view-mode",
                options=[
                    {"label": "Single crystal", "value": "single-crystal"},
                    {"label": "3D powder", "value": "3d-powder"},
                    {"label": "2D powder", "value": "2d-powder"},
                    {"label": "Cylinder", "value": "cylinder"},
                ],
                value=resolved_view,
                className="simulation-powder-options",
                labelClassName="simulation-powder-option",
                inputClassName="simulation-powder-input",
            ),
        ],
        className="simulation-powder-control",
    )


def _build_peak_selector_card(
    key: str,
    label: str,
    options: tuple[tuple[str, Any], ...],
    value: list[int],
) -> html.Div:
    return html.Div(
        [
            html.Div(
                [
                    html.Div(label, className="simulation-peak-selector-title"),
                    html.Div(
                        f"{len(value)} of {len(options)} peaks visible",
                        className="simulation-peak-selector-count",
                    ),
                ],
                className="simulation-peak-selector-header",
            ),
            dcc.Checklist(
                id={"type": "powder-qr-control", "key": key},
                options=[
                    {"label": option_label, "value": option_value}
                    for option_label, option_value in options
                ],
                value=value,
                className="simulation-peak-selector-list",
                labelClassName="simulation-peak-selector-option",
                inputClassName="simulation-peak-selector-input",
            ),
        ],
        className="simulation-peak-selector-card",
    )


def _build_powder_selector_controls(
    selection_state: dict[str, Any] | None = None,
    powder_view: Any = None,
) -> list[html.Div]:
    catalog = _powder_selector_catalog()
    selection = _resolved_powder_selection_state(selection_state)
    resolved_view = _resolved_powder_view(powder_view)

    controls: list[html.Div] = [_build_powder_view_control(resolved_view)]
    selector_specs = {
        "3d-powder": (
            POWDER_SPHERE_SELECTION_KEY,
            "Visible |G| shells",
            catalog["sphere_options"],
        ),
        "2d-powder": (
            POWDER_RING_SELECTION_KEY,
            "Visible 2D powder peaks",
            catalog["ring_options"],
        ),
        "cylinder": (
            POWDER_CYLINDER_SELECTION_KEY,
            "Visible cylinder peaks",
            catalog["cylinder_options"],
        ),
    }

    active_selector = selector_specs.get(resolved_view)
    if active_selector is not None:
        key, label, options = active_selector
        controls.append(
            _build_peak_selector_card(
                key,
                label,
                options,
                selection[key],
            )
        )
    else:
        controls.append(
            html.Div(
                [
                    html.Div("Peak filters", className="simulation-peak-selector-title"),
                    html.Div(
                        "Single crystal does not use grouped powder peak filters.",
                        className="simulation-peak-selector-empty-text",
                    ),
                ],
                className="simulation-powder-empty",
            )
        )
    return controls


SIMULATION_SPECS: dict[str, SimulationSpec] = {
    "reciprocal-space": SimulationSpec(
        key="reciprocal-space",
        label="Powder Views",
        description=(
            "Single-crystal, 3D powder, 2D powder, and cylinder reciprocal-space "
            "views in one Plotly figure."
        ),
        controls=(
            ControlSpec("theta_i_min_deg", "θᵢ min (deg)", "number", 0.0, step=1.0),
            ControlSpec("theta_i_max_deg", "θᵢ max (deg)", "number", 90.0, step=1.0),
            ControlSpec("frames", "frames", "number", N_FRAMES_DEFAULT, step=1, min=2.0),
            ControlSpec(
                "render_profile",
                "render profile",
                "dropdown",
                "balanced",
                options=(("Balanced", "balanced"), ("Full", "full")),
            ),
        ),
        build_figure=_build_reciprocal_space_figure,
    ),
    "detector-view": SimulationSpec(
        key="detector-view",
        label="Mosaic View",
        description=(
            "Three-panel detector simulation linking reciprocal-space geometry, detector "
            "intensity, and centered integration."
        ),
        controls=_mosaic_theta_hkl_controls(),
        build_figure=_build_detector_adapter,
    ),
    SPECIAL_CAUSE_RECIPROCAL_MODE: SimulationSpec(
        key=SPECIAL_CAUSE_RECIPROCAL_MODE,
        label="Special Cause Reciprocal",
        description=(
            "One-panel physical reciprocal-space view of the Cu-Kα Ewald sphere, "
            "Bi2Se3 Bragg sphere, and their mosaic-weighted overlap."
        ),
        controls=_special_cause_reciprocal_controls(),
        build_figure=_build_special_cause_reciprocal_adapter,
    ),
    "fibrous-view": SimulationSpec(
        key="fibrous-view",
        label="Ewald Cylinder",
        description=(
            "Fibrous Bragg/Ewald/cylinder overlap view with the same HKL and mosaic controls."
        ),
        controls=_hkl_controls(),
        build_figure=_build_fibrous_adapter,
    ),
    SPECULAR_MODE: SimulationSpec(
        key=SPECULAR_MODE,
        label="Specular Diffraction",
        description=(
            "Specular reflection geometry with beam, sample, detector, and diffraction controls."
        ),
        controls=_specular_controls(),
        build_figure=lambda values: _build_specular_adapter(values)[0],
    ),
}


_NON_SPECULAR_CONTROL_SECTIONS: dict[str, tuple[tuple[str, tuple[str, ...]], ...]] = {
    "reciprocal-space": (
        ("Sweep", ("theta_i_min_deg", "theta_i_max_deg")),
        ("Render", ("frames", "render_profile")),
    ),
    "detector-view": _MOSAIC_CONTROL_SECTIONS,
    SPECIAL_CAUSE_RECIPROCAL_MODE: _SPECIAL_CAUSE_CONTROL_SECTIONS,
    "fibrous-view": (
        ("Reflection", ("H", "K", "L")),
        ("Mosaic Envelope", ("sigma_deg", "Gamma_deg", "eta", "wavelength_bandwidth_pct")),
    ),
}


def _build_control(control: ControlSpec, value: Any) -> html.Div:
    control_id = {"type": "simulation-control", "key": control.key}
    label_content: Any
    if isinstance(control.label, SpecularMathLabel):
        label_content = html.Span(
            [
                control.label.symbol,
                html.Sub(control.label.subscript) if control.label.subscript is not None else None,
                control.label.suffix,
            ]
        )
    else:
        label_content = control.label

    if control.component == "dropdown":
        component = dcc.Dropdown(
            id=control_id,
            options=[{"label": label, "value": option_value} for label, option_value in control.options],
            value=value,
            clearable=False,
        )
    elif control.component == "checklist":
        component = dcc.Checklist(
            id=control_id,
            options=[{"label": "Enabled", "value": "enabled"}],
            value=["enabled"] if bool(value) else [],
            className="simulation-control-checklist",
            labelClassName="simulation-control-check-option",
            inputClassName="simulation-control-check-input",
        )
    elif control.component == "slider":
        midpoint = 0.5 * (float(control.min) + float(control.max))
        component = dcc.Slider(
            id=control_id,
            min=control.min,
            max=control.max,
            step=control.step,
            value=value,
            updatemode="drag" if control.key == "theta_i_deg" else "mouseup",
            marks={
                float(control.min): f"{control.min:g}",
                midpoint: f"{midpoint:g}",
                float(control.max): f"{control.max:g}",
            },
        )
    elif control.component == "slider_input":
        slider_id = {"type": "simulation-hybrid-slider", "key": control.key}
        input_id = {"type": "simulation-hybrid-input", "key": control.key}
        marks = {
            float(control.min): f"{control.min:g}",
            float(control.max): f"{control.max:g}",
        }
        component = html.Div(
            [
                html.Div(
                    dcc.Slider(
                        id=slider_id,
                        min=control.min,
                        max=control.max,
                        step=control.step,
                        value=value,
                        updatemode=control.updatemode or "mouseup",
                        marks=marks,
                        tooltip={"placement": "bottom", "always_visible": False},
                    ),
                    className="simulation-control-slider",
                ),
                dcc.Input(
                    id=input_id,
                    type="number",
                    value=value,
                    step=control.input_step if control.input_step is not None else control.step,
                    min=control.min,
                    max=control.max,
                    debounce=True,
                    className="simulation-control-number",
                ),
            ],
            className="simulation-control-pair",
        )
    elif control.component == "range":
        component = dcc.RangeSlider(
            id=control_id,
            min=control.min,
            max=control.max,
            step=control.step,
            value=list(value),
            allowCross=False,
            marks={
                float(control.min): f"{control.min:g}",
                0.5 * (float(control.min) + float(control.max)): f"{0.5 * (float(control.min) + float(control.max)):g}",
                float(control.max): f"{control.max:g}",
            },
        )
    else:
        component = dcc.Input(
            id=control_id,
            type="number",
            value=value,
            step=control.step,
            min=control.min,
            max=control.max,
            debounce=True,
            className="simulation-control-input",
        )

    return html.Div(
        [
            html.Label(label_content),
            component,
        ],
        className="simulation-control",
    )


def _build_control_section(title: str, controls: list[html.Div]) -> html.Section:
    section_key = title.lower().replace(" ", "-")
    return html.Section(
        [
            html.Div(title, className="simulation-control-section-title"),
            html.Div(controls, className="simulation-control-grid"),
        ],
        className=f"simulation-control-section simulation-control-section--{section_key}",
    )


def _build_controls_for_mode(
    mode: str,
    values: dict[str, Any],
    powder_selection_state: dict[str, Any] | None = None,
    powder_view: Any = None,
) -> list[html.Div]:
    if mode == SPECULAR_MODE:
        return _build_specular_control_sections(values)

    spec = SIMULATION_SPECS[mode]
    control_lookup = {control.key: control for control in spec.controls}
    controls = [
        _build_control_section(
            title,
            [_build_control(control_lookup[key], values[key]) for key in control_keys],
        )
        for title, control_keys in _NON_SPECULAR_CONTROL_SECTIONS[mode]
    ]
    if mode == "reciprocal-space":
        controls.extend(_build_powder_selector_controls(powder_selection_state, powder_view))
    return controls


def build_unified_figure(mode: str = DEFAULT_MODE, **values: Any) -> go.Figure:
    """Return the figure for the selected simulation mode."""

    mode_key = _resolve_mode(mode)
    merged_values = _merged_mode_state(mode_key, values)
    return _build_simulation_outputs(mode_key, merged_values)[0]


def build_unified_app(
    initial_mode: str = DEFAULT_MODE,
    *,
    initial_state: dict[str, dict[str, Any]] | None = None,
) -> Dash:
    """Return a single Dash app that can switch between the supported views."""

    mode = _resolve_mode(initial_mode)
    state = _seeded_state(initial_state)
    powder_selection_state = _default_powder_selection_state()
    powder_view_state = DEFAULT_POWDER_VIEW
    initial_values = _merged_mode_state(mode, state.get(mode))
    initial_spec = SIMULATION_SPECS[mode]
    if mode == SPECULAR_MODE:
        initial_figure, initial_companion_figure, initial_summary = _build_specular_dashboard_adapter(
            initial_values
        )
    else:
        initial_figure, initial_summary = _build_simulation_outputs(mode, initial_values)
        initial_companion_figure = go.Figure()
    if mode == SPECULAR_MODE:
        initial_figure = set_figure_meta_value(
            initial_figure,
            SPECULAR_MAIN_SIGNATURE_META,
            specular_signature_from_values(initial_values, SPECULAR_CONTROL_NAMES),
        )
        initial_figure = set_figure_meta_value(initial_figure, "simulation_summary", initial_summary)
        initial_companion_figure = set_figure_meta_value(
            initial_companion_figure,
            SPECULAR_COMPANION_SIGNATURE_META,
            specular_signature_from_values(initial_values, SPECULAR_COMPANION_CONTROL_NAMES),
        )
    shell_class_name, sidebar_class_name = _shell_class_names(mode)
    main_title, main_caption = _main_visual_copy(mode)

    assets_folder = Path(__file__).resolve().parent.parent / "assets"
    app = Dash(__name__, suppress_callback_exceptions=True, assets_folder=str(assets_folder))
    app.title = "Unified Mosaic Simulator"
    app.layout = html.Div(
        [
            dcc.Store(id="simulation-state", data=state),
            dcc.Store(id="powder-selection-state", data=powder_selection_state),
            dcc.Store(id="powder-view-state", data=powder_view_state),
            dcc.Store(id="simulation-camera-state", data={}),
            dcc.Store(id="simulation-summary-text", data=initial_summary),
            dcc.Store(id="powder-selector-sync", data={}),
            dcc.Store(id="special-cause-matrix-export-figure", data=None, storage_type="memory"),
            html.Div(
                [
                    html.Div(
                        [
                            html.Header(
                                [
                                    html.Div(
                                        [
                                            html.Div("Mosaic Simulator", className="simulation-app-title"),
                                            html.Div("Browser workbench", className="simulation-app-kicker"),
                                        ],
                                        className="simulation-brand",
                                    ),
                                    html.Div(
                                        [
                                            html.Label("Mode", className="simulation-mode-label"),
                                            html.Div(
                                                "Switch views quickly; each mode keeps its own controls while you compare outputs.",
                                                className="simulation-mode-helper",
                                            ),
                                            dcc.RadioItems(
                                                id="simulation-mode",
                                                options=[
                                                    {"label": spec.label, "value": spec.key}
                                                    for spec in SIMULATION_SPECS.values()
                                                ],
                                                value=mode,
                                                className="simulation-mode-picker",
                                                labelClassName="simulation-mode-option",
                                                inputClassName="simulation-mode-input",
                                                inline=True,
                                            ),
                                        ],
                                        className="simulation-mode-card",
                                    ),
                                ],
                                id="simulation-sidebar-header",
                                className="simulation-sidebar-header",
                            ),
                            html.Div(
                                initial_spec.description,
                                id="simulation-description",
                                className="simulation-description",
                            ),
                            html.Div(
                                id="simulation-summary",
                                children=build_specular_summary_card(initial_summary),
                                className="specular-summary-shell",
                                style=_summary_style(mode, initial_summary),
                            ),
                            html.Div(
                                _build_controls_for_mode(
                                    mode,
                                    initial_values,
                                    powder_selection_state,
                                    powder_view_state,
                                ),
                                id="simulation-controls",
                                className="simulation-controls",
                            ),
                        ],
                        id="simulation-sidebar",
                        className=sidebar_class_name,
                    ),
                    html.Div(
                        [
                            html.Div(
                                [
                                    html.Button(
                                        "Save PNG",
                                        id="export-png-button",
                                        n_clicks=0,
                                        title="Download the current visualization as a PNG",
                                        className="simulation-toolbar-button",
                                    ),
                                    html.Button(
                                        "Save 3x3 Matrix",
                                        id="export-special-cause-matrix-button",
                                        n_clicks=0,
                                        title="Download a 3x3 special-cause comparison using the current camera",
                                        className="simulation-toolbar-button",
                                        style=_special_cause_matrix_export_style(mode),
                                    ),
                                    html.Div(
                                        [
                                            html.Div(
                                                id="export-png-status",
                                                className="simulation-toolbar-status",
                                            ),
                                            html.Div(
                                                id="export-special-cause-matrix-status",
                                                className="simulation-toolbar-status",
                                            ),
                                        ],
                                        className="simulation-toolbar-status-group",
                                    ),
                                ],
                                className="simulation-toolbar",
                            ),
                            html.Section(
                                [
                                    html.Div(
                                        [
                                            html.H2(
                                                main_title,
                                                id="simulation-main-title",
                                            ),
                                            html.Div(
                                                main_caption,
                                                id="simulation-main-caption",
                                                className="simulation-main-caption",
                                            ),
                                        ],
                                        className="simulation-visual-header",
                                    ),
                                    html.Div(
                                        [
                                            dcc.Graph(
                                                id="simulation-figure",
                                                figure=initial_figure,
                                                responsive=True,
                                                style={"height": "100%", "minHeight": "0"},
                                                config={"displaylogo": False},
                                            )
                                        ],
                                        className="simulation-graph-frame simulation-graph-frame--primary",
                                    ),
                                ],
                                id="simulation-primary-card",
                                className="simulation-visual-card simulation-visual-card--hero",
                            ),
                            html.Section(
                                [
                                    html.Div(
                                        [
                                            html.H3(
                                                "Reciprocal Space and Integrated Response",
                                            ),
                                            html.Div(
                                                "The synchronized mosaic reciprocal-space and centered-integration panels for the current specular HKL and θᵢ.",
                                                className="simulation-main-caption",
                                            ),
                                        ],
                                        className="simulation-visual-header",
                                    ),
                                    html.Div(
                                        [
                                            dcc.Graph(
                                                id="simulation-specular-companion-figure",
                                                figure=initial_companion_figure,
                                                responsive=True,
                                                style={"height": "100%", "minHeight": "0"},
                                                config={"displaylogo": False},
                                            ),
                                        ],
                                        className="simulation-graph-frame simulation-graph-frame--secondary",
                                    ),
                                ],
                                id="simulation-specular-companion-card",
                                className="simulation-visual-card",
                                style=_specular_companion_style(mode),
                            ),
                        ],
                        id="simulation-main",
                        className="simulation-main",
                    ),
                ],
                id="simulation-shell",
                className=shell_class_name,
            ),
        ]
    )

    @app.callback(
        Output("simulation-state", "data"),
        Input({"type": "simulation-control", "key": ALL}, "value"),
        Input({"type": "simulation-hybrid-input", "key": ALL}, "value"),
        State("simulation-mode", "value"),
        State({"type": "simulation-control", "key": ALL}, "id"),
        State({"type": "simulation-hybrid-input", "key": ALL}, "id"),
        State("simulation-state", "data"),
        prevent_initial_call=True,
    )
    def cache_control_values(
        values,
        hybrid_values,
        mode_value,
        control_ids,
        hybrid_ids,
        state_value,
    ):  # pragma: no cover - UI callback
        updated_state = _updated_mode_state(
            mode_value,
            values,
            hybrid_values,
            control_ids,
            hybrid_ids,
            state_value,
            ctx.triggered_id,
        )
        if updated_state is None:
            raise PreventUpdate
        return updated_state

    @app.callback(
        Output({"type": "simulation-hybrid-slider", "key": MATCH}, "value"),
        Output({"type": "simulation-hybrid-input", "key": MATCH}, "value"),
        Input({"type": "simulation-hybrid-slider", "key": MATCH}, "value"),
        Input({"type": "simulation-hybrid-input", "key": MATCH}, "value"),
        prevent_initial_call=True,
    )
    def sync_hybrid_control(slider_value, input_value):  # pragma: no cover - UI callback
        triggered_id = ctx.triggered_id
        if not isinstance(triggered_id, dict):
            raise PreventUpdate

        if triggered_id.get("type") == "simulation-hybrid-input":
            value = input_value
            if value is None:
                value = slider_value
        else:
            value = slider_value

        if value is None:
            raise PreventUpdate

        return value, value

    @app.callback(
        Output("powder-view-state", "data"),
        Input("powder-view-mode", "value"),
        State("powder-view-state", "data"),
        prevent_initial_call=True,
    )
    def cache_powder_view_value(value, current_value):  # pragma: no cover - UI callback
        updated_view = _updated_powder_view(value, current_value)
        if updated_view is None:
            raise PreventUpdate
        return updated_view

    @app.callback(
        Output("powder-selection-state", "data"),
        Input({"type": "powder-qr-control", "key": ALL}, "value"),
        State({"type": "powder-qr-control", "key": ALL}, "id"),
        State("powder-selection-state", "data"),
        prevent_initial_call=True,
    )
    def cache_powder_selection_values(values, control_ids, state_value):  # pragma: no cover - UI callback
        updated_state = _updated_powder_selection_state(values, control_ids, state_value)
        if updated_state is None:
            raise PreventUpdate
        return updated_state

    @app.callback(
        Output("simulation-description", "children"),
        Output("simulation-controls", "children"),
        Output("simulation-main-title", "children"),
        Output("simulation-main-caption", "children"),
        Input("simulation-mode", "value"),
        Input("powder-view-state", "data"),
        State("simulation-state", "data"),
        State("powder-selection-state", "data"),
        prevent_initial_call=True,
    )
    def render_mode_controls(
        mode_value,
        powder_view_value,
        state_value,
        powder_state_value,
    ):  # pragma: no cover - UI callback
        mode_key = _resolve_mode(mode_value)
        spec = SIMULATION_SPECS[mode_key]
        values = _merged_mode_state(mode_key, (state_value or {}).get(mode_key))
        main_title, main_caption = _main_visual_copy(mode_key)
        return (
            spec.description,
            _build_controls_for_mode(
                mode_key,
                values,
                powder_state_value,
                powder_view_value,
            ),
            main_title,
            main_caption,
        )

    @app.callback(
        Output("simulation-shell", "className"),
        Output("simulation-sidebar", "className"),
        Input("simulation-mode", "value"),
        prevent_initial_call=True,
    )
    def render_shell_classes(mode_value):  # pragma: no cover - UI callback
        return _shell_class_names(_resolve_mode(mode_value))

    @app.callback(
        Output("export-special-cause-matrix-button", "style"),
        Input("simulation-mode", "value"),
    )
    def render_special_cause_matrix_export_button(mode_value):  # pragma: no cover - UI callback
        return _special_cause_matrix_export_style(_resolve_mode(mode_value))

    @app.callback(
        Output("special-cause-matrix-export-figure", "data"),
        Input("export-special-cause-matrix-button", "n_clicks"),
        State("simulation-mode", "value"),
        State("simulation-state", "data"),
        State("simulation-camera-state", "data"),
        State("simulation-figure", "relayoutData"),
        prevent_initial_call=True,
    )
    def prepare_special_cause_matrix_export(
        n_clicks,
        mode_value,
        state_value,
        camera_state_value,
        relayout_data,
    ):  # pragma: no cover - UI callback
        mode_key = _resolve_mode(mode_value)
        if not n_clicks or mode_key != SPECIAL_CAUSE_RECIPROCAL_MODE:
            raise PreventUpdate

        values = _merged_mode_state(mode_key, (state_value or {}).get(mode_key))
        camera_state = dict(camera_state_value or {})
        camera = camera_state.get(mode_key) or extract_scene_camera(relayout_data)
        try:
            figure_data = _build_special_cause_matrix_figure(values, camera=camera).to_plotly_json()
            figure_data["export_request"] = n_clicks
            return figure_data
        except ValueError as exc:
            return {"error": str(exc)}

    @app.callback(
        Output("simulation-specular-companion-card", "style"),
        Input("simulation-mode", "value"),
        prevent_initial_call=True,
    )
    def render_specular_companion_card(mode_value):  # pragma: no cover - UI callback
        return _specular_companion_style(_resolve_mode(mode_value))

    @app.callback(
        Output("simulation-camera-state", "data"),
        Input("simulation-figure", "relayoutData"),
        Input("simulation-specular-companion-figure", "relayoutData"),
        State("simulation-mode", "value"),
        State("simulation-camera-state", "data"),
        prevent_initial_call=True,
    )
    def cache_camera_state(
        relayout_data,
        companion_relayout_data,
        mode_value,
        camera_state_value,
    ):  # pragma: no cover - UI callback
        mode_key = _resolve_mode(mode_value)
        camera_state = dict(camera_state_value or {})
        updated_state = dict(camera_state)
        changed = False

        if mode_key in SCENE_CAMERA_MODES:
            camera = extract_scene_camera(relayout_data)
            if camera and camera_state.get(mode_key) != camera:
                updated_state[mode_key] = camera
                changed = True

        if mode_key == SPECULAR_MODE:
            companion_key = _specular_companion_camera_key(mode_key)
            companion_camera = extract_scene_camera(companion_relayout_data)
            if companion_camera and camera_state.get(companion_key) != companion_camera:
                updated_state[companion_key] = companion_camera
                changed = True

        if not changed:
            raise PreventUpdate
        return updated_state

    @app.callback(
        Output("simulation-figure", "figure"),
        Input("simulation-mode", "value"),
        Input("simulation-state", "data"),
        State("simulation-camera-state", "data"),
        State("simulation-figure", "relayoutData"),
        State("simulation-figure", "figure"),
        prevent_initial_call=True,
    )
    def render_main_figure(
        mode_value,
        state_value,
        camera_state_value,
        relayout_data,
        current_figure,
    ):  # pragma: no cover - UI callback
        mode_key = _resolve_mode(mode_value)
        values = _merged_mode_state(mode_key, (state_value or {}).get(mode_key))
        camera_state = dict(camera_state_value or {})
        camera = None
        if mode_key in SCENE_CAMERA_MODES:
            camera = camera_state.get(mode_key) or extract_scene_camera(relayout_data)

        if mode_key == SPECULAR_MODE:
            signature = specular_signature_from_values(values, SPECULAR_CONTROL_NAMES)
            if (
                extract_figure_meta_value(current_figure, SPECULAR_MAIN_SIGNATURE_META) == signature
                and extract_scene_camera_from_figure_value(current_figure) == camera
            ):
                raise PreventUpdate
            figure, summary = _build_specular_main_adapter(
                values,
                camera=camera,
            )
            figure = set_figure_meta_value(
                figure,
                SPECULAR_MAIN_SIGNATURE_META,
                signature,
            )
            return set_figure_meta_value(figure, "simulation_summary", summary)

        return _build_simulation_outputs(mode_key, values, camera=camera)[0]

    @app.callback(
        Output("simulation-specular-companion-figure", "figure"),
        Input("simulation-mode", "value"),
        Input("simulation-state", "data"),
        State("simulation-camera-state", "data"),
        State("simulation-specular-companion-figure", "relayoutData"),
        State("simulation-specular-companion-figure", "figure"),
        prevent_initial_call=True,
    )
    def render_specular_companion_figure(
        mode_value,
        state_value,
        camera_state_value,
        companion_relayout_data,
        current_figure,
    ):  # pragma: no cover - UI callback
        mode_key = _resolve_mode(mode_value)
        if mode_key != SPECULAR_MODE:
            return go.Figure()

        values = _merged_mode_state(mode_key, (state_value or {}).get(mode_key))
        signature = specular_signature_from_values(values, SPECULAR_COMPANION_CONTROL_NAMES)
        camera_state = dict(camera_state_value or {})
        companion_camera = (
            camera_state.get(_specular_companion_camera_key(mode_key))
            or extract_scene_camera(companion_relayout_data)
        )
        if (
            extract_figure_meta_value(current_figure, SPECULAR_COMPANION_SIGNATURE_META) == signature
            and extract_scene_camera_from_figure_value(current_figure) == companion_camera
        ):
            raise PreventUpdate

        figure = _build_specular_companion_adapter(values, camera=companion_camera)
        return set_figure_meta_value(
            figure,
            SPECULAR_COMPANION_SIGNATURE_META,
            signature,
        )

    @app.callback(
        Output("simulation-summary", "children"),
        Output("simulation-summary", "style"),
        Output("simulation-summary-text", "data"),
        Input("simulation-mode", "value"),
        Input("simulation-state", "data"),
        State("simulation-summary-text", "data"),
        prevent_initial_call=True,
    )
    def render_summary(mode_value, state_value, current_summary_text):  # pragma: no cover - UI callback
        mode_key = _resolve_mode(mode_value)
        if mode_key != SPECULAR_MODE:
            return "", _summary_style(mode_key, ""), ""

        values = _merged_mode_state(mode_key, (state_value or {}).get(mode_key))
        summary = _build_specular_summary_adapter(values)
        if current_summary_text == summary:
            raise PreventUpdate
        return build_specular_summary_card(summary), _summary_style(mode_key, summary), summary

    app.clientside_callback(
        PNG_EXPORT_CLIENTSIDE_CALLBACK,
        Output("export-png-status", "children"),
        Input("export-png-button", "n_clicks"),
        State("simulation-mode", "value"),
        prevent_initial_call=True,
    )
    app.clientside_callback(
        SPECIAL_CAUSE_MATRIX_EXPORT_CLIENTSIDE_CALLBACK,
        Output("export-special-cause-matrix-status", "children"),
        Input("special-cause-matrix-export-figure", "data"),
        prevent_initial_call=True,
    )
    app.clientside_callback(
        POWDER_QR_CLIENTSIDE_CALLBACK,
        Output("powder-selector-sync", "data"),
        Input("simulation-mode", "value"),
        Input("simulation-figure", "figure"),
        Input("powder-selection-state", "data"),
        Input("powder-view-state", "data"),
        prevent_initial_call=True,
    )

    return app


def parse_args() -> argparse.Namespace:
    """Parse CLI arguments for the unified simulator."""

    parser = argparse.ArgumentParser(
        description="Unified GUI for the supported simulation views"
    )
    parser.add_argument(
        "--mode",
        choices=tuple(SIMULATION_SPECS),
        default=DEFAULT_MODE,
        help="initial simulation mode",
    )
    parser.add_argument(
        "--host",
        default=DEFAULT_HOST,
        help=f"Dash host (default: {DEFAULT_HOST})",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=DEFAULT_PORT,
        help=f"Dash port (default: {DEFAULT_PORT})",
    )
    parser.add_argument(
        "--no-browser",
        action="store_true",
        help="start the server without opening a browser tab",
    )
    parser.add_argument(
        "--state-json",
        help="initial simulation-state JSON payload used to seed the GUI",
    )
    return parser.parse_args()


def _parse_initial_state_json(
    raw_state: str | None,
) -> dict[str, dict[str, Any]] | None:
    if raw_state is None:
        return None
    try:
        parsed = json.loads(raw_state)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid --state-json payload: {exc.msg}") from exc
    if not isinstance(parsed, dict):
        raise ValueError("Initial state JSON must decode to an object.")
    return parsed


def main(
    mode: str | None = None,
    *,
    host: str | None = None,
    port: int | None = None,
    open_browser: bool | None = None,
    initial_state: dict[str, dict[str, Any]] | None = None,
) -> None:
    """Launch the unified simulator app."""

    if (
        mode is None
        and host is None
        and port is None
        and open_browser is None
        and initial_state is None
    ):
        args = parse_args()
        resolved_mode = _resolve_mode(args.mode)
        resolved_host = str(args.host)
        resolved_port = int(args.port)
        resolved_open_browser = not args.no_browser
        resolved_initial_state = _parse_initial_state_json(args.state_json)
    else:
        resolved_mode = _resolve_mode(mode)
        resolved_host = DEFAULT_HOST if host is None else str(host)
        resolved_port = DEFAULT_PORT if port is None else int(port)
        resolved_open_browser = True if open_browser is None else bool(open_browser)
        resolved_initial_state = initial_state

    app = build_unified_app(
        initial_mode=resolved_mode,
        initial_state=resolved_initial_state,
    )
    url = f"http://{resolved_host}:{resolved_port}"
    if resolved_open_browser:
        threading.Timer(1.0, lambda: webbrowser.open_new(url)).start()
    app.run(debug=False, host=resolved_host, port=resolved_port)


if __name__ == "__main__":
    args = parse_args()
    main(
        args.mode,
        host=args.host,
        port=args.port,
        open_browser=not args.no_browser,
    )
